package semana04;

import java.util.ArrayList;
import java.util.Iterator;

public class Simulacion01 {

	public static void main(String[] args) {
		
		ArrayList<Thread> filosofos = new ArrayList<Thread>();
		
		int N = 5;
		
		for(int i=0; i<N; i=i+1) {
			filosofos.add(new Filosofo());//new
		}
		
		Iterator<Thread> iter = filosofos.iterator();
		
		while(iter.hasNext()) {
			iter.next().start();//start()
		}
		

	}

}
