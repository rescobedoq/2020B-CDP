package semana04;

import javax.swing.JTextArea;

public class Filosofo2 extends Thread {
	
	JTextArea mensajes;
	
	public Filosofo2(JTextArea pantalla) {
		this.mensajes = pantalla;
	}
	
	
	@SuppressWarnings("static-access")
	public void run() {//runnable
		
		while(true) {
			
			//System.out.println(this.getName() + " Hola estoy despierto...");
			mensajes.append(this.getName() + " Hola estoy despierto..." + "\n");
									
		}
		
		
	}

}
