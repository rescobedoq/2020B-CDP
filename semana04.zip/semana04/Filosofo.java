package semana04;

public class Filosofo extends Thread {
	
	
	@SuppressWarnings("static-access")
	public void run() {//runnable
		
		for(int i=1;i<=100;i=i+10) {
			
			System.out.println(this.getName() + " Hola estoy despierto... " + i);
			
			
			
		}
		
		
	}

}
