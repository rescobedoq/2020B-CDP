package semana04;


public class Simulacion03 {

	public static void main(String[] args) {
		
		Filosofo f01 = new Filosofo();
		Filosofo f02 = new Filosofo();
		Filosofo f03 = new Filosofo();
		
		f01.start();
		
		f02.start();
		
		f03.start();
		

	}

}
