package sesion01;

public class Hilo02 extends Persona implements Runnable {

	public Hilo02(boolean genero) {
		super(genero);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		for(;;) {
			
			
		}
		
	}

}
