package sesion01;

public class Alumno extends Persona {
	
	String nombre;
	
	public Alumno(String a, boolean b) {
		super(b);
		this.nombre = a;
		this.genero = b;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	

}
