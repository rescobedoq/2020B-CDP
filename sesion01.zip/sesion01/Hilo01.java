package sesion01;

public class Hilo01 extends Thread {
	
	String name;

	public Hilo01(String name) {
		this.name = name;
	}
	
	@Override
	public void run() {
		
		for(int algo=1;algo<=10;algo++) {
			System.out.println(this.name + " : " + algo);
		}
		
		
	}
	
	

}
