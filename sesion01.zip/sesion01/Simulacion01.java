package sesion01;

public class Simulacion01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hilo01 h01 = new Hilo01("NOD");
		Hilo01 h02 = new Hilo01("AVG");
		
		h01.start();
		h02.start();
		
		
	}

}
