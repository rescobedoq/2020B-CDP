package sesion01;

public class Hilo2 {
	
	String name;

	public Hilo2(String name) {
		this.name = name;
	}
	
	
	public void ejecucion() {
		
		for(int algo=1;algo<=10;algo++) {
			System.out.println(this.name + " : " + algo);
		}
		
		
	}
	
	

}
