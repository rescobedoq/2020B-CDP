package sesion01;

public class Persona {
	
	boolean genero;

	public Persona(boolean genero) {
		super();
		this.genero = genero;
	}

	public boolean isGenero() {
		return genero;
	}

	public void setGenero(boolean genero) {
		this.genero = genero;
	}
	
	

}
