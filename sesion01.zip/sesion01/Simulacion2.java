package sesion01;

public class Simulacion2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hilo2 h01 = new Hilo2("NOD");
		Hilo2 h02 = new Hilo2("AVG");
		
		h01.ejecucion();
		h02.ejecucion();
		
		
	}

}
