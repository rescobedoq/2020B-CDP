package sesion01;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello world!");
		
		Alumno a01 = new Alumno("Sara", false);
		Alumno a02 = new Alumno("Augusto", false);
		Alumno a03 = new Alumno("Frans", false);
		Alumno a04 = new Alumno("Joel", false);
		
		System.out.println(a01.getNombre());
		System.out.println(a04.getNombre());
		a04.setNombre("Jhoel");
		System.out.println(a04.getNombre());
	}

}
